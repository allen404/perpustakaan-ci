<div class="jumbotron">
    <h1 class="display-4">Selamat Datang,  <?= $_SESSION['nama'] ?>!</h1>
    <p class="lead">Selamat datang di menu perpustakaan, silahkan pilih menu diatas</p>
</div>
<script type="text/javascript" src="https://code.jquery.com/jquery-3.4.1.js"></script>