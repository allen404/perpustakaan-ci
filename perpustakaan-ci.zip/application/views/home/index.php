<div class="jumbotron">
    <h1 class="display-4">Selamat Datang,  <?= $_SESSION['nama'] ?>!</h1>
    <p class="lead">Selamat datang di menu perpustakaan, silahkan pilih menu diatas</p>
  <hr class="my-4">
  <p>It uses utility classes for typography and spacing to space content out within the larger container.</p>
  <p class="lead">
    <a class="btn btn-primary btn-lg" href="#" role="button">Learn more</a>
  </p>
</div>


<script
  src="https://code.jquery.com/jquery-3.4.1.js"
  integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
  crossorigin="anonymous"></script>
