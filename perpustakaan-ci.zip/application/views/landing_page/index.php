<div class="jumbotron">
    <h1 class="display-4">Selamat Datang!<h1>
    <p class="lead">Selamat datang di menu perpustakaan, silahkan login atau masuk sebagai tamu</p>
    <a class="btn btn-primary btn-lg" href="#" role="button">Learn more</a>
  </p>
</div>