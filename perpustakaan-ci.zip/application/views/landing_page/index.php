<div class="jumbotron">
    <h1 class="display-4">Selamat Datang!<h1>
    <p class="lead">Selamat datang di menu perpustakaan, silahkan login atau masuk sebagai tamu</p>
  </p>
</div>

<script
  src="https://code.jquery.com/jquery-3.4.1.js"
  integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
  crossorigin="anonymous"></script>
